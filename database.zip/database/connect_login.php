<?php 
    session_start();
?>

<?php
$servername = "localhost:3306";
$username_db = "root";
$password_db = "";
$database_name = "db_sekolah";

$email = $_POST["email"];
$password = $_POST["password"];

// Membuat koneksi ke database
$conn = new mysqli($servername, $username_db, $password_db, $database_name);

// Memeriksa apakah koneksi berhasil
if ($conn->connect_error) {
    die("Koneksi database gagal : " . $conn->connect_error);
} else {
    // Menyiapkan query SQL untuk mengambil data admin berdasarkan email
    $stmt = $conn->prepare("SELECT * FROM admin WHERE email = ?");

    // Mengikat parameter ke statement
    $stmt->bind_param("s", $email);

    // Menjalankan query
    $stmt->execute();
    
    $stmt_result = $stmt->get_result();
    if ($stmt_result->num_rows > 0) {
        $data = $stmt_result->fetch_assoc();
        if ($data['password'] === $password) {
            // session_start(); // Mulai sesi
            $_SESSION['logged_in'] = true; // Tetapkan sesi 'logged_in' menjadi true
            // $_SESSION['email'] = $email; // Tetapkan sesi 'email' dengan nilai email pengguna
            header("Location: read.php"); // Alihkan ke halaman 'read.php' setelah berhasil login
        } else {
            echo "<h2> Email atau password salah </h2>";
        }
    } else {
        echo "<h2> Email atau password salah";
    }
}
?>
